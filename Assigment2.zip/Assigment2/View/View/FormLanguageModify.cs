﻿using Controller;
using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    public partial class FormLanguageModify : Form
    {
        public FormLanguageModify()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string slanguageName = textBox3.Text;

            LanguageController languageController = new LanguageController();
            int iRowCount = languageController.SaveLanguage(slanguageName);

            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, save in unsuccessful");

            }
            else
            {
                MessageBox.Show("Save is successful");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
           int sLid = Convert.ToInt32(textBox1.Text);

            LanguageController languageController = new LanguageController();
            int iRowCount = languageController.DeleteLanguage(sLid);

            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, delete in unsuccessful");

            }
            else
            {
                MessageBox.Show("Delete is successful");
            }
        }

        private void FormLanguageModify_Load(object sender, EventArgs e)
        {
           LanguageController languageController = new LanguageController();
            List<Language> languages = languageController.BrowseLanguage();

            dataGridView1.DataSource = languages;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int sLid = Convert.ToInt32(textBox4.Text);
            string sLanguageName = textBox2.Text;


            LanguageController languageController = new LanguageController();
            int iRowCount = languageController.UpdateLanguage(sLanguageName, sLid);



            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, Update in unsuccessful");

            }
            else
            {
                MessageBox.Show("Update is successful");
            }
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }
    }
}
