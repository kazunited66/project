﻿using Controller;
using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    public partial class FormBorrow : Form
    {
        public FormBorrow()
        {
            InitializeComponent();
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sUID= Convert.ToInt32(textBox1.Text);
            string sISBN = textBox2.Text;
            string sBorrowDate = Convert.ToString(textBox1.Text);
            string sReturnDate = Convert.ToString(textBox4.Text);


            

            BorrowController borrowController = new BorrowController();
            int iRowCount = borrowController.SaveBorrow(sUID, sISBN,sBorrowDate, sReturnDate);



            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, borrow in unsuccessful");

            }
            else
            {
                MessageBox.Show("Borrow is successful");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormBorrow_Load(object sender, EventArgs e)
        {
            BorrowController borrowController = new BorrowController();
            List<Borrow> borrows = borrowController.BrowseBorrow();

            dataGridView1.DataSource = borrows;
        }
    }
}
