﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    public partial class FormStudentDashboard : Form
    {
        public FormStudentDashboard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormBookBrowsing browseBook = new FormBookBrowsing();
            browseBook.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormSearchBook searchBook = new FormSearchBook();
            searchBook.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormUserModify modifyUser = new FormUserModify();
            modifyUser.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            FormBorrow bookBorrow = new FormBorrow();
            bookBorrow.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            FormReserved bookReserved = new FormReserved();
            bookReserved.Show();
        }

        private void FormStudentDashboard_Load(object sender, EventArgs e)
        {

        }
    }
}
