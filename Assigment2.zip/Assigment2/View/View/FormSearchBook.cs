﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Controller;
using Model;

namespace View
{
    public partial class FormSearchBook : Form
    {
        public FormSearchBook()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sBookName = textBox3.Text;
            

            BookController bookController = new BookController();
            List<Book> book = bookController.SearchBookName(sBookName);
            
            
            dataGridView1.DataSource = book;
            

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            string sBookName = textBox3.Text;

            BookController bookController = new BookController();
            List<Book> book = bookController.SearchBookName(sBookName);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string sBookPublisher = textBox3.Text;

            BookController bookController = new BookController();
            List<Book> book = bookController.SearchBookPublisher(sBookPublisher);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            string sBookPublisher = textBox1.Text;

            BookController bookController = new BookController();
            
            List<Book> book = bookController.SearchBookPublisher(sBookPublisher);

            dataGridView1.DataSource = book;
        }

        private void FormSearchBook_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int sBookPublishYear = Convert.ToInt32(textBox2.Text);

            BookController bookController = new BookController();

            List<Book> book = bookController.SearchBookPublishYear(sBookPublishYear);

            dataGridView1.DataSource = book;

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }



}

