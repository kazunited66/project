﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    public partial class FormManagerDashboard : Form
    {
        public FormManagerDashboard()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FormCategoryModify modifyCategory = new FormCategoryModify();
            modifyCategory.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FormLanguageModify modifyLanguage = new FormLanguageModify();
            modifyLanguage.Show();
        }

        private void FormManagerDashboard_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            FormAuthorModify modifyAuthor = new FormAuthorModify();
            modifyAuthor.Show();
        }
    }
}
