﻿using Controller;
using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace View
{
    public partial class FormUserModify : Form
    {
        public FormUserModify()
        {
            InitializeComponent();
        }

        private void label9_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string sUserName = textBox1.Text;
            string sPassword = textBox2.Text;
            int sUserLevel = Convert.ToInt32(textBox3.Text);

            UserController userController = new UserController();
            int iRowCount = userController.SaveUser(sUserName,sPassword,sUserLevel);

      

            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, save in unsuccessful");

            }
            else
            {
                MessageBox.Show("Save is successful");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
           
            int sUid = Convert.ToInt32(textBox8.Text);

            UserController userController = new UserController();
            int iRowCount = userController.DeleteUser(sUid);

            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, delete in unsuccessful");

            }
            else
            {
                MessageBox.Show("Delete is successful");
            }
        }

        private void FormUserModify_Load(object sender, EventArgs e)
        {
            UserController userController = new UserController();
            List<User> users = userController.GetAllUsers();

            dataGridView1.DataSource = users;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int sUid = Convert.ToInt32(textBox4.Text);
            string sUserName = textBox5.Text;
            string sPassword = textBox6.Text;
            int sUserLevel = Convert.ToInt32(textBox7.Text);

            UserController userController = new UserController();
            int iRowCount = userController.UpdateUser(sUserName, sPassword, sUserLevel, sUid);



            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, Update in unsuccessful");

            }
            else
            {
                MessageBox.Show("Update is successful");
            }
        }
    }
}
