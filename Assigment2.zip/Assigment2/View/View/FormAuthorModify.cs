﻿using Controller;
using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    public partial class FormAuthorModify : Form
    {
        public FormAuthorModify()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sAuthorName = textBox1.Text;

            AuthorController authorController = new AuthorController();
            int iRowCount = authorController.SaveAuthor(sAuthorName);

            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, save in unsuccessful");

            }
            else
            {
                MessageBox.Show("Save is successful");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sAid = Convert.ToInt32(textBox2.Text);

            AuthorController authorController = new AuthorController();
            int iRowCount = authorController.DeleteAuthor(sAid);

            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, delete in unsuccessful");

            }
            else
            {
                MessageBox.Show("Delete is successful");
            }
        }

        private void FormAuthorModify_Load(object sender, EventArgs e)
        {
            AuthorController authorController = new AuthorController();
            List<Author> author = authorController.BrowseAuthor();

            dataGridView1.DataSource = author;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int sAid = Convert.ToInt32(textBox3.Text);
            string sAuthorName = textBox4.Text;


            AuthorController authorController = new AuthorController();
            int iRowCount = authorController.UpdateAuthor(sAuthorName, sAid);



            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, Update in unsuccessful");

            }
            else
            {
                MessageBox.Show("Update is successful");
            }
        }
    }
   }

