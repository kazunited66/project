﻿using Controller;
using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

      

        private void button2_Click(object sender, EventArgs e)
        {
            string sUserName = textBox3.Text;
            string sPassword = textBox4.Text;

            //connect to the Controller 

            UserController userController = new UserController();
            User user = userController.ValideLogin(sUserName);


            if (user == null)
            {
                MessageBox.Show("User not found. Please type valied User ");
                return;
            }

            if(sUserName== sPassword) {
                if (user.UserLevel == 1)
                {
                    //redirect to the Student dashboard
                    FormStudentDashboard studentDashboard = new FormStudentDashboard();
                    studentDashboard.Show();
                }

                else if (user.UserLevel == 2)
                {
                    //redirect to the staff dashboard
                    FormStaffDashboard staffDashboard = new FormStaffDashboard();
                    staffDashboard.Show();
                }
                else if (user.UserLevel == 3)
                {
                    //redirect to the Student dashboard
                    FormManagerDashboard managerDashboard = new FormManagerDashboard();
                    managerDashboard.Show();
                }

            }

            else
            {
                MessageBox.Show("Incorrect user name or password ");
            }




        }
    }

}