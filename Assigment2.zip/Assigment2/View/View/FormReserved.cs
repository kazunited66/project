﻿using Controller;
using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace View
{
    public partial class FormReserved : Form
    {
        public FormReserved()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int sUID = Convert.ToInt32(textBox1.Text);
            string sISBN = textBox2.Text;
            string sReservedDate = textBox3.Text;
            



            ReservedController reservedController = new ReservedController();
            int iRowCount = reservedController.SaveReserved(sUID, sISBN, sReservedDate);



            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, reserve in unsuccessful");

            }
            else
            {
                MessageBox.Show("Reserve is successful");
            }
        }

        private void FormReserved_Load(object sender, EventArgs e)
        {
            ReservedController reservedController = new ReservedController();
            List<Reserved> reserveds = reservedController.BrowseReserved();

            dataGridView1.DataSource = reserveds;
        }
    }
}
