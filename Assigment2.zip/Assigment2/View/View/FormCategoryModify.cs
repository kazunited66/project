﻿using Controller;
using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace View
{
    public partial class FormCategoryModify : Form
    {
        public FormCategoryModify()
        {
            InitializeComponent();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string sCategoryName = textBox3.Text;

            CategoryController categoryController = new CategoryController();
            int iRowCount = categoryController.SaveCategory(sCategoryName);

            if(iRowCount == -1 ) {
                MessageBox.Show("Sorry, save in unsuccessful");

            }
            else
            {
                MessageBox.Show("Save is successful");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int sCid = Convert.ToInt32(textBox1.Text);

            CategoryController categoryController = new CategoryController();
            int iRowCount = categoryController.DeleteCategory(sCid);

            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, delete in unsuccessful");

            }
            else
            {
                MessageBox.Show("Delete is successful");
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           
        }

        private void FormMasterInformation_Load(object sender, EventArgs e)
        {
            CategoryController categoryController = new CategoryController();
            List<Category> categories = categoryController.BrowseCategory();

            dataGridView1.DataSource = categories;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int sCid = Convert.ToInt32(textBox4.Text);
            string sCategoryName = textBox2.Text;
            

            CategoryController categoryController = new CategoryController();
            int iRowCount = categoryController.UpdateCategory(sCategoryName,sCid);



            if (iRowCount == -1)
            {
                MessageBox.Show("Sorry, Update in unsuccessful");

            }
            else
            {
                MessageBox.Show("Update is successful");
            }
        }
    }
}
