﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Controller
{
    public class UserController
    {
        public List<User> GetAllUsers()
        {
            UserLogic userLogic = new UserLogic();
            List<User> users = userLogic.GetAllUsers();
            return users;
        }

        public User  ValideLogin(string sUserName)
        {
            UserLogic userLogic = new UserLogic();
            User users =  userLogic.ValideLogin(sUserName);
            return users;

        }

        public int SaveUser(string sUserName,string sPassword,int sUserLevel)
        {

            UserLogic userLogic = new UserLogic();
            int iRowCount = userLogic.SaveUser(sUserName,sPassword,sUserLevel);
            return iRowCount;
        }

        public int DeleteUser(int sUid)
        {

            UserLogic userLogic = new UserLogic();
            int iRowCount = userLogic.DeleteUser(sUid);
            return iRowCount;
        }

        public int UpdateUser(string sUserName, string sPassword, int sUserLevel, int sUid)
        {

            UserLogic userLogic = new UserLogic();
            int iRowCount = userLogic.UpdateUser(sUserName, sPassword, sUserLevel,sUid);
            return iRowCount;
        }
    }
}

