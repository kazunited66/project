﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controller
{
    public class ReservedController
    {

        public int SaveReserved(int sUID, string sISBN, string sReservedDate)
        {

            ReservedLogic reservedLogic= new ReservedLogic();
            int iRowCount = reservedLogic.SaveReserved(sUID, sISBN, sReservedDate);
            return iRowCount;
        }

        public List<Reserved> BrowseReserved()
        {
            ReservedLogic reservedLogic = new ReservedLogic();
            List<Reserved> reserveds = reservedLogic.BrowseReserved();
            return reserveds;
        }
    }
}
