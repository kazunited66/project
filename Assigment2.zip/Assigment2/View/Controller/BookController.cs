﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Controller
{
    public class BookController
    {
        public List<Book> SearchBookName(string sBookName)
        {
            BookLogic bookLogic = new BookLogic();
            List<Book> books = bookLogic.SearchBookName(sBookName);
            return books;
        }

        public List<Book> SearchBookPublisher(string sBookPublisher)
        {

            BookLogic bookLogic = new BookLogic();
            List<Book> books = bookLogic.SearchBookPublisher(sBookPublisher);
            return books;

        }

        public List<Book> SearchBookPublisher(object sBookPublisher)
        {
            throw new NotImplementedException();
        }

        public List<Book> SearchBookPublishYear(int sBookPublishYear)
        {

            BookLogic bookLogic = new BookLogic();
            List<Book> books = bookLogic.SearchBookPublishYear(sBookPublishYear);
            return books;

        }


        public List<Book> BrowseBook()
        {
            BookLogic bookLogic = new BookLogic();
            List<Book> books = bookLogic.BrowseBook();
            return books;
        }
    }
}
