﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model;

namespace Controller
{
    public class CategoryController
    {
        public int SaveCategory(string sCategoryName) { 

            CategoryLogic categoryLogic = new CategoryLogic();
            int iRowCount = categoryLogic.SaveCategory(sCategoryName);
            return iRowCount;
         }

        public int DeleteCategory(int sCid)
        {

            CategoryLogic categoryLogic = new CategoryLogic();
            int iRowCount = categoryLogic.DeleteCategory(sCid);
            return iRowCount;
        }

        public List<Category> BrowseCategory()
        {
            CategoryLogic categoryLogic = new CategoryLogic();
            List<Category> categories = categoryLogic.BrowseCategory();
            return categories;
        }

        public int UpdateCategory(string sCategoryName, int sCid)
        {

            CategoryLogic categoryLogic = new CategoryLogic();
            int iRowCount = categoryLogic.UpdateCategory(sCategoryName, sCid);
            return iRowCount;
        }
    }
}
