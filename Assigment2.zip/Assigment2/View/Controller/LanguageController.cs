﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controller
{
    public class LanguageController
    {
        public int SaveLanguage(string slanguageName)
        {

            LanguageLogic languageLogic = new LanguageLogic();
            int iRowCount = languageLogic.SaveLanguage(slanguageName);
            return iRowCount;
        }

        public int DeleteLanguage(int sLid)
        {

            LanguageLogic languageLogic = new LanguageLogic();
            int iRowCount = languageLogic.DeleteLanguage(sLid);
            return iRowCount;
        }

        public List<Language> BrowseLanguage()
        {
            LanguageLogic languageLogic = new LanguageLogic();
            List<Language> languages = languageLogic.BrowseLanguage();
            return languages;
        }

        public int UpdateLanguage(string sLanguageName, int sLid)
        {

            LanguageLogic languageLogic = new LanguageLogic();
            int iRowCount = languageLogic.UpdateLanguage(sLanguageName, sLid);
            return iRowCount;
        }
    }
}
