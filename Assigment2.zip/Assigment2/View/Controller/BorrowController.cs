﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controller
{
    public class BorrowController
    {
        public int SaveBorrow(int sUID, string sISBN, string sBorrowDate, string sReturnDate)
        {

            BorrowLogic borrowLogic = new BorrowLogic();
            int iRowCount = borrowLogic.SaveBorrow(sUID, sISBN, sBorrowDate, sReturnDate);
            return iRowCount;
        }

        public List<Borrow> BrowseBorrow()
        {
            BorrowLogic borrowLogic = new BorrowLogic();
            List<Borrow> borrows = borrowLogic.BrowseBorrow();
            return borrows;
        }
    }
}
