﻿using Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Controller
{
    public class AuthorController
    {
        public int SaveAuthor(string sAuthorName)
        {

            AuthorLogic authorLogic = new AuthorLogic();
            int iRowCount = authorLogic.SaveAuthor(sAuthorName);
            return iRowCount;
        }

        public int DeleteAuthor(int sAid)
        {

            AuthorLogic authorLogic = new AuthorLogic();
            int iRowCount = authorLogic.DeleteAuthor(sAid);
            return iRowCount;
        }

        public List<Author> BrowseAuthor()
        {
            AuthorLogic authorLogic = new AuthorLogic();
            List<Author> authors= authorLogic.BrowseAuthor();
            return authors;
        }

        public int UpdateAuthor(string sAuthorName, int sAid)
        {

            AuthorLogic authorLogic = new AuthorLogic();
            int iRowCount = authorLogic.UpdateAuthor(sAuthorName, sAid);
            return iRowCount;
        }
    }
}
