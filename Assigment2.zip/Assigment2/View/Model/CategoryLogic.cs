﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class CategoryLogic
    {

        public int SaveCategory(string sCategoryName)
        {
           CategoryDAO categoryDAO = new CategoryDAO();
           int iRowCount=categoryDAO.SaveCategory(sCategoryName);
           return iRowCount;
         }

        public int DeleteCategory(int sCid)
        {
            CategoryDAO categoryDAO = new CategoryDAO();
            int iRowCount = categoryDAO.DeleteCategory(sCid);
            return iRowCount;
        }

        public List<Category> BrowseCategory()
        {
            CategoryDAO categoryLogic = new CategoryDAO();
            List<Category> categories = categoryLogic.BrowseCategory();
            return categories;
        }

        public int UpdateCategory(string sCategoryName, int sCid)
        {

            CategoryDAO categoryDAO = new CategoryDAO();
            int iRowCount = categoryDAO.UpdateCategory(sCategoryName,sCid);
            return iRowCount;
        }
    }
}
