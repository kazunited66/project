﻿using Model.DataSetUserTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Model.DataSetUser;
using System.Security.Cryptography.X509Certificates;
using System.Security.Cryptography;
using Model.DataSetAuthorTableAdapters;

namespace Model
{
    public class UserDAO
    {
        public List<User> GetAllUsers()
        {

            //connects to the database 

             TabUserTableAdapter tabUserTableAdapter = new TabUserTableAdapter();
             DataSetUser.TabUserDataTable tabUserDataTable = tabUserTableAdapter.GetAllUsers();
            

            int dataCount = tabUserDataTable.Count;

            if (dataCount == 0)
            {

                return null;
            }
            else
            {

                List<User> users = new List<User>();


                foreach (DataRow row in tabUserDataTable)
                {
                    int uid = Convert.ToInt32(row["UID"]);
                    string userName = row["UserName"].ToString();
                    string password = row["Password"].ToString();
                    int userLevel = Convert.ToInt32(row["UserLevel"]);


                    User user = new User();
                    user.Uid = uid;
                    user.UserName = userName;
                    user.Password = password;
                    user.UserLevel = userLevel;

                    users.Add(user);
                }

                return users;
            }

           
        }

          public User ValideLogin(string sUserName)
          {
            //connect to the Database
            TabUserTableAdapter tabUserTableAdapter = new TabUserTableAdapter();
            DataSetUser.TabUserDataTable tabUserDataTable = tabUserTableAdapter.ValideLogin(sUserName);

            int dataCount = tabUserDataTable.Count;

            if (dataCount == 0)
            {
                //this means invalid username
                return null;
            }
            else
            {
                //valid username
                //create an object of user entity class 
                User user = new User();
                //access the return row which is the tabUserDataTable object
                DataRow userDataRow = tabUserDataTable.Rows[0];

                user.Uid = Convert.ToInt32(userDataRow["UID"]);
                user.UserName = userDataRow["UserName"].ToString();
                user.Password = userDataRow["Password"].ToString();
                user.UserLevel = Convert.ToInt32(userDataRow["UserLevel"]); 

                return user;
            }
           }


        public int SaveUser(string sUserName, string sPassword, int sUserLevel)
        {
            //connect to the Database

            TabUserTableAdapter tabUserTableAdapter = new TabUserTableAdapter();
            int iRowCount = tabUserTableAdapter.SaveUser( sUserName, sPassword, sUserLevel);
            return iRowCount;
        }

        public int DeleteUser( int sUid)
        {
            //connect to the Database

            TabUserTableAdapter tabUserTableAdapter = new TabUserTableAdapter();
            int iRowCount = tabUserTableAdapter.DeleteUser(sUid);
            return iRowCount;
        }

        public int UpdateUser(string sUserName, string sPassword, int sUserLevel, int sUid)
        {
            //connect to the Database

            TabUserTableAdapter tabUserTableAdapter = new TabUserTableAdapter();
            int iRowCount = tabUserTableAdapter.UpdateUser(sUserName, sPassword, sUserLevel,sUid);
            return iRowCount;
        }



    }

}
