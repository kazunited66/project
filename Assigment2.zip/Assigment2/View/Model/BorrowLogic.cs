﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class BorrowLogic
    {

        public int SaveBorrow(int sUID, string sISBN, string sBorrowDate, string sReturnDate)
        {

            BorrowDAO borrowDAO = new BorrowDAO();
            int iRowCount = borrowDAO.SaveBorrow(sUID, sISBN, sBorrowDate, sReturnDate);
            return iRowCount;
        }

        public List<Borrow> BrowseBorrow()
        {
            BorrowDAO borrowDAO = new BorrowDAO();
            List<Borrow> borrows = borrowDAO.BrowseBorrow();
            return borrows;
        }
    }
}
