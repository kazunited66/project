﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class AuthorLogic
    {
        public int SaveAuthor(string sAuthorName)
        {

            AuthorDAO authorDAO = new AuthorDAO();
            int iRowCount = authorDAO.SaveAuthor(sAuthorName);
            return iRowCount;
        }

        public int DeleteAuthor(int sAid)
        {

            AuthorDAO authorDAO = new AuthorDAO();
            int iRowCount = authorDAO.DeleteAuthor(sAid);
            return iRowCount;
        }

        public List<Author> BrowseAuthor()
        {
            AuthorDAO authorDAO = new AuthorDAO();
            List<Author> authors = authorDAO.BrowseAuthor();
            return authors;
        }

        public int UpdateAuthor(string sAuthorName, int sAid)
        {

            AuthorDAO authorDAO = new AuthorDAO();
            int iRowCount = authorDAO.UpdateAuthor(sAuthorName, sAid);
            return iRowCount;
        }
    }
}
