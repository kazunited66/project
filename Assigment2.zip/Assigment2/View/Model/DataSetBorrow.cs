﻿namespace Model
{


    public partial class DataSetBorrow
    {
    }
}

namespace Model.DataSetBorrowTableAdapters {
    
    
    public partial class TabBorrowTableAdapter {
    }
}
