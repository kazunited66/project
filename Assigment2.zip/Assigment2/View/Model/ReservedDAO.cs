﻿using Model.DataSetReservedTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Model
{
    public class ReservedDAO
    {
        public int SaveReserved(int sUID, string sISBN, string sReservedDate)
        {
            //connect to the Database

            TabReservedTableAdapter tabReservedTableAdapter = new TabReservedTableAdapter();
            int iRowCount = tabReservedTableAdapter.SaveReserved(sUID, sISBN, sReservedDate);

            return iRowCount;
        }

        public List<Reserved> BrowseReserved()
        {

            //connects to the database 

            TabReservedTableAdapter tabReservedTableAdapter = new TabReservedTableAdapter();
            DataSetReserved.TabReservedDataTable tabReservedDataTable = tabReservedTableAdapter.RrowseReserved();


            int dataCount = tabReservedDataTable.Count;

            if (dataCount == 0)
            {

                return null;
            }
            else
            {

                List<Reserved> reserveds = new List<Reserved>();


                foreach (DataRow row in tabReservedDataTable)
                {
                    int uid = Convert.ToInt32(row["UID"]);
                    string isbn = row["ISBN"].ToString();
                    string reservedDate = row["ReservedDate"].ToString();




                    Reserved reserved = new Reserved();
                    reserved.Uid = uid;
                    reserved.Isbn = isbn;
                    reserved.ReservedDate= reservedDate;
                    reserveds.Add(reserved);

                }

                return reserveds;
            }


        }
    }
}
