﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Reserved
    {

        int uid;
        string isbn;
        string reservedDate;

        public int Uid { get => uid; set => uid = value; }
        public string Isbn { get => isbn; set => isbn = value; }
        public string ReservedDate { get => reservedDate; set => reservedDate = value; }
    }
}
