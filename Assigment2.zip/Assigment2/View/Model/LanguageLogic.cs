﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class LanguageLogic
    {
        public int SaveLanguage(string slanguageName)
        {

            LanguageDAO languageDAO = new LanguageDAO();
            int iRowCount = languageDAO.SaveLanguage(slanguageName);
            return iRowCount;
        }

        public int DeleteLanguage(int sLid)
        {

            LanguageDAO languageDAO = new LanguageDAO();
            int iRowCount = languageDAO.DeleteLanguage(sLid);
            return iRowCount;
        }

        public List<Language> BrowseLanguage()
        {
            LanguageDAO languageDAO = new LanguageDAO();
            List<Language> languages = languageDAO.BrowseLanguage();
            return languages;
        }

        public int UpdateLanguage(string sLanguageName, int sLid)
        {

            LanguageDAO languageDAO= new LanguageDAO();
            int iRowCount = languageDAO.UpdateLanguage(sLanguageName, sLid);
            return iRowCount;
        }
    }
}
