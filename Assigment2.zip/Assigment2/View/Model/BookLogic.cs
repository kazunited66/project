﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class BookLogic
    {
        public List<Book> SearchBookName(string sBookName)
        {
            BookDAO bookDAO = new BookDAO();
            List<Book>books = bookDAO.SearchBookName(sBookName);
            return books;
        }

        public List<Book> SearchBookPublisher(string sBookPublisher)
        {

            BookDAO bookDAO = new BookDAO();
            List<Book>books = bookDAO.SearchBookPublisher(sBookPublisher);
            return books;

        }

        public List<Book> SearchBookPublishYear(int sBookPublishYear)
        {

            BookDAO bookDAO = new BookDAO();
            List<Book> books = bookDAO.SearchBookPublishYear(sBookPublishYear);
            return books;

        }

        public List<Book> BrowseBook()
        {
            BookDAO bookDAO = new BookDAO();
            List<Book> books = bookDAO.BrowseBook();
            return books;
        }
    }
}
