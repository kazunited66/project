﻿using Model.DataSetCategoryTableAdapters;
using Model.DataSetLanguageTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class LanguageDAO
    {
        public int SaveLanguage(string sLanguageName)
        {
            //connect to the Database

            TabLanguageTableAdapter tabLanguageTableAdapter = new TabLanguageTableAdapter();
            int iRowCount = tabLanguageTableAdapter.SaveLanguage(sLanguageName);
            return iRowCount;
        }

        public int DeleteLanguage(int sLid)
        {
            //connect to the Database

            TabLanguageTableAdapter tabLanguageTableAdapter = new TabLanguageTableAdapter();
            int iRowCount = tabLanguageTableAdapter.DeleteLanguage(sLid);
            return iRowCount;
        }

        public List<Language> BrowseLanguage()
        {

            //connects to the database 

            TabLanguageTableAdapter tabLanguageTableAdapter = new TabLanguageTableAdapter();
            DataSetLanguage.TabLanguageDataTable tabLanguageDataTable = tabLanguageTableAdapter.BrowseLanguage();


            int dataCount = tabLanguageDataTable.Count;

            if (dataCount == 0)
            {

                return null;
            }
            else
            {

                List<Language> Language = new List<Language>();

                foreach (DataRow row in tabLanguageDataTable)
                {
                    int lid = Convert.ToInt32(row["LID"]);
                    string languageName = row["LanguageName"].ToString();
                    

                    Language language = new Language();
                    language.Lid = lid;
                    language.LanguageName = languageName;


                    Language.Add(language);



                }


                return Language;
            }





        }

        public int UpdateLanguage(string sLanguageName, int sLid)
        {
            //connect to the Database

            TabLanguageTableAdapter tabLanguageTableAdapter = new TabLanguageTableAdapter();
            int iRowCount = tabLanguageTableAdapter.UpdateLanguage(sLanguageName,sLid);
            return iRowCount;



        }
    }
}
