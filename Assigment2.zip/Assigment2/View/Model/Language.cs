﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Language
    {
        string languageName;
        int lid;

        public string LanguageName { get => languageName; set => languageName = value; }
        public int Lid { get => lid; set => lid = value; }
    }
}
