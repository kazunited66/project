﻿namespace Model
{


    partial class DataSetUser
    {
    }
}

namespace Model.DataSetUserTableAdapters {
    
    
    public partial class TabUserTableAdapter {
    }
}
