﻿using Model.DataSetAuthorTableAdapters;
using Model.DataSetLanguageTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class AuthorDAO
    {
        
            public int SaveAuthor(string sAuthorName)
            {
                //connect to the Database

                TabAuthorTableAdapter tabAuthorTableAdapter = new TabAuthorTableAdapter();
                int iRowCount = tabAuthorTableAdapter.SaveAuthor(sAuthorName);
                return iRowCount;
            }

            public int DeleteAuthor(int sAid)
            {
            //connect to the Database

            TabAuthorTableAdapter tabAuthorTableAdapter = new TabAuthorTableAdapter();
            int iRowCount = tabAuthorTableAdapter.DeleteAuthor(sAid);
            return iRowCount;
            
            }

            public List<Author> BrowseAuthor()
            {

            //connects to the database 

            TabAuthorTableAdapter tabAuthorTableAdapter = new TabAuthorTableAdapter();
            DataSetAuthor.TabAuthorDataTable tabAuthorDataTable = tabAuthorTableAdapter.BrowseAuthor();


                int dataCount = tabAuthorDataTable.Count;

                if (dataCount == 0)
                {

                    return null;
                }
                else
                {

                    List<Author> Author = new List<Author>();

                    foreach (DataRow row in tabAuthorDataTable)
                    {
                        int aid = Convert.ToInt32(row["AID"]);
                        string authorName = row["AuthorName"].ToString();


                        Author author = new Author();
                        author.Aid = aid;
                        author.AuthorName = authorName;


                        Author.Add(author);



                    }


                    return Author;
                }





            }

             public int UpdateAuthor(string sAuthorName, int sAid)
             {
            //connect to the Database

            TabAuthorTableAdapter tabAuthorTableAdapter = new TabAuthorTableAdapter();
            int iRowCount = tabAuthorTableAdapter.UpdateAuthor(sAuthorName,sAid);
            return iRowCount;



              }
    }

    
}
