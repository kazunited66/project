﻿using Model.DataSetUserTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Model.DataSetBookTableAdapters;
using static Model.DataSetUser;


namespace Model
{
    public class BookDAO
    {
        public List<Book> SearchBookName(string sBookName)
        {

            //connects to the database 

            TabBookTableAdapter tabBookTableAdapter = new TabBookTableAdapter();
            DataSetBook.TabBookDataTable tabBookDataTable = tabBookTableAdapter.SearchBookName(sBookName);


            int dataCount = tabBookDataTable.Count;

            if (dataCount == 0)
            {

                return null;
            }
            else
            {

                List<Book> Books = new List<Book>();
                
                foreach(DataRow row in tabBookDataTable)
                {
                    string isbn = row["ISBN"].ToString();
                    string bookName = row["BookName"].ToString();
                    int author = Convert.ToInt32(row["Author"]);
                    int category = Convert.ToInt32(row["Category"]);
                    int language = Convert.ToInt32(row["Language"]);
                    int publishYear = Convert.ToInt32(row["PublishYear"]);
                    int pages = Convert.ToInt32(row["Pages"]);
                    string publisher = row["Publisher"].ToString();


                    Book book = new Book();
                    book.Isbn = isbn;
                    book.BookName = bookName;
                    book.Author = author;
                    book.Category = category;
                    book.Language = language;
                    book.PublishYear = publishYear;
                    book.Pages = pages;
                    book.Publisher = publisher;
                    Books.Add(book);
                    


                }


                return Books;
            }
        }
        public List<Book> SearchBookPublisher(string sBookPublisher)
        {

            //connects to the database 

            TabBookTableAdapter tabBookTableAdapter = new TabBookTableAdapter();
            DataSetBook.TabBookDataTable tabBookDataTable = tabBookTableAdapter.SearchBookPublisher(sBookPublisher);


            int dataCount = tabBookDataTable.Count;

            if (dataCount == 0)
            {

                return null;
            }
            else
            {

                List<Book> Books = new List<Book>();

                foreach (DataRow row in tabBookDataTable)
                {
                    string isbn = row["ISBN"].ToString();
                    string bookName = row["BookName"].ToString();
                    int author = Convert.ToInt32(row["Author"]);
                    int category = Convert.ToInt32(row["Category"]);
                    int language = Convert.ToInt32(row["Language"]);
                    int publishYear = Convert.ToInt32(row["PublishYear"]);
                    int pages = Convert.ToInt32(row["Pages"]);
                    string publisher = row["Publisher"].ToString();


                    Book book = new Book();
                    book.Isbn = isbn;
                    book.BookName = bookName;
                    book.Author = author;
                    book.Category = category;
                    book.Language = language;
                    book.PublishYear = publishYear;
                    book.Pages = pages;
                    book.Publisher = publisher;

                    Books.Add(book);



                }


                return Books;
            }


        }


        public List<Book> SearchBookPublishYear(int sBookPublishYear)
        {

            //connects to the database 

            TabBookTableAdapter tabBookTableAdapter = new TabBookTableAdapter();
            DataSetBook.TabBookDataTable tabBookDataTable = tabBookTableAdapter.SearchBookPublishYear(sBookPublishYear);


            int dataCount = tabBookDataTable.Count;

            if (dataCount == 0)
            {

                return null;
            }
            else
            {

                List<Book> Books = new List<Book>();

                foreach (DataRow row in tabBookDataTable)
                {
                    string isbn = row["ISBN"].ToString();
                    string bookName = row["BookName"].ToString();
                    int author = Convert.ToInt32(row["Author"]);
                    int category = Convert.ToInt32(row["Category"]);
                    int language = Convert.ToInt32(row["Language"]);
                    int publishYear = Convert.ToInt32(row["PublishYear"]);
                    int pages = Convert.ToInt32(row["Pages"]);
                    string publisher = row["Publisher"].ToString();


                    Book book = new Book();
                    book.Isbn = isbn;
                    book.BookName = bookName;
                    book.Author = author;
                    book.Category = category;
                    book.Language = language;
                    book.PublishYear = publishYear;
                    book.Pages = pages;
                    book.Publisher = publisher;

                    Books.Add(book);



                }


                return Books;
            }


        }


        public List<Book> BrowseBook()
        {

            //connects to the database 

            TabBookTableAdapter tabBookTableAdapter = new TabBookTableAdapter();
            DataSetBook.TabBookDataTable tabBookDataTable = tabBookTableAdapter.BrowseBook();


            int dataCount = tabBookDataTable.Count;

            if (dataCount == 0)
            {

                return null;
            }
            else
            {

                List<Book> Books = new List<Book>();

                foreach (DataRow row in tabBookDataTable)
                {
                    string isbn = row["ISBN"].ToString();
                    string bookName = row["BookName"].ToString();
                    int author = Convert.ToInt32(row["Author"]);
                    int category = Convert.ToInt32(row["Category"]);
                    int language = Convert.ToInt32(row["Language"]);
                    int publishYear = Convert.ToInt32(row["PublishYear"]);
                    int pages = Convert.ToInt32(row["Pages"]);
                    string publisher = row["Publisher"].ToString();


                    Book book = new Book();
                    book.Isbn = isbn;
                    book.BookName = bookName;
                    book.Author = author;
                    book.Category = category;
                    book.Language = language;
                    book.PublishYear = publishYear;
                    book.Pages = pages;
                    book.Publisher = publisher;

                    Books.Add(book);



                }


                return Books;
            }





        }



    }

    }

