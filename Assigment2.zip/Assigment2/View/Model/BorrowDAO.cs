﻿using Model.DataSetBorrowTableAdapters;
using Model.DataSetUserTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{

    public class BorrowDAO
    {
        
        public int SaveBorrow(int sUID, string sISBN, string sBorrowDate, string sReturnDate)
        {
           
            //connect to the Database
           // sBorrowDate.ToString();//
           // sReturnDate.ToString();//
            TabBorrowTableAdapter tabBorrowTableAdapter = new TabBorrowTableAdapter();
            int iRowCount = tabBorrowTableAdapter.SaveBorrow(sUID, sISBN, sBorrowDate, sReturnDate);
            
            return iRowCount;
        }

        public List<Borrow> BrowseBorrow()
        {

            //connects to the database 

            TabBorrowTableAdapter tabBorrowTableAdapter = new TabBorrowTableAdapter();
            DataSetBorrow.TabBorrowDataTable tabBorrowDataTable = tabBorrowTableAdapter.BrowseBorrow();


            int dataCount = tabBorrowDataTable.Count;

            if (dataCount == 0)
            {

                return null;
            }
            else
            {

                List<Borrow> borrows = new List<Borrow>();


                foreach (DataRow row in tabBorrowDataTable)
                {
                    int uid = Convert.ToInt32(row["UID"]);
                    string isbn = row["ISBN"].ToString();
                    string borrowDate = row["BorrowDate"].ToString();
                    string returnDate = row["ReturnDate"].ToString();
                    
           
                 
                    Borrow borrow = new Borrow();
                    borrow.Uid = uid;
                    borrow.Isbn = isbn;
                    borrow.BorrowDate= borrowDate;
                    borrow.ReturnDate= returnDate;
                    

                    borrows.Add(borrow);
                }

                return borrows;
            }


        }
    }
}
