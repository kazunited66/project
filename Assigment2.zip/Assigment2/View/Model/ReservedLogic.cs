﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class ReservedLogic
    {

        public int SaveReserved(int sUID, string sISBN, string sReservedDate)
        {

            ReservedDAO reservedDAO = new ReservedDAO();
            int iRowCount = reservedDAO.SaveReserved(sUID, sISBN, sReservedDate);
            return iRowCount;
        }

        public List<Reserved> BrowseReserved()
        {
            ReservedDAO reservedDAO =new ReservedDAO();
            List<Reserved> reserveds = reservedDAO.BrowseReserved();
            return reserveds;
        }
    }
}
