﻿namespace Model
{


    public partial class DataSetLanguage
    {
    }
}
namespace Model {
    
    
    public partial class DataSetLanguage {
    }
}
