﻿using Model.DataSetBookTableAdapters;
using Model.DataSetCategoryTableAdapters;
using Model.DataSetUserTableAdapters;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class CategoryDAO
    {
        public int SaveCategory(string sCategoryName)
        {
            //connect to the Database

            TabCategoryTableAdapter tabCategoryTableAdapter = new TabCategoryTableAdapter();
            int iRowCount = tabCategoryTableAdapter.SaveCategory(sCategoryName);
            return iRowCount;
        }

        public int DeleteCategory(int sCid)
        {
            //connect to the Database

            TabCategoryTableAdapter tabCategoryTableAdapter = new TabCategoryTableAdapter();
            int iRowCount = tabCategoryTableAdapter.DeleteCategory(sCid);
            return iRowCount;
        }

        public List<Category> BrowseCategory()
        {

            //connects to the database 

            TabCategoryTableAdapter tabCategoryTableAdapter = new TabCategoryTableAdapter();
            DataSetCategory.TabCategoryDataTable tabCategoryDataTable = tabCategoryTableAdapter.BrowseCategory();


            int dataCount = tabCategoryDataTable.Count;

            if (dataCount == 0)
            {

                return null;
            }
            else
            {

                List<Category> Category = new List<Category>();

                foreach (DataRow row in tabCategoryDataTable)
                {
                    int cid = Convert.ToInt32(row["CID"]);
                    string categoryName = row["CategoryName"].ToString();


                    Category category = new Category();
                    category.Cid = cid;
                    category.CategoryName = categoryName;


                    Category.Add(category);



                }


                return Category;
            }


        }

        public int UpdateCategory(string sCategoryName, int sCid)
        {
            //connect to the Database

            TabCategoryTableAdapter tabCategoryTableAdapter = new TabCategoryTableAdapter();
            int iRowCount = tabCategoryTableAdapter.UpdateCategory(sCategoryName,sCid);
            return iRowCount;



        }


    }
}
