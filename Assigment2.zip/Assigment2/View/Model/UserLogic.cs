﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class UserLogic
    {

        public List<User> GetAllUsers()
        {
            UserDAO usersDAO = new UserDAO();
            List<User> users = usersDAO.GetAllUsers();
            return users;
        }

        public User ValideLogin(string sUserName)
        {
            UserDAO userDAO = new UserDAO();
            User users = userDAO.ValideLogin(sUserName);
            return users;
         
        }

        public int SaveUser(string sUserName, string sPassword, int sUserLevel)
        {

            UserDAO userDAO = new UserDAO();
            int iRowCount = userDAO.SaveUser(sUserName, sPassword, sUserLevel);
            return iRowCount;
        }

        public int DeleteUser(int sUid)
        {

            UserDAO userDAO = new UserDAO();
            int iRowCount = userDAO.DeleteUser(sUid);
            return iRowCount;
        }

        public int UpdateUser(string sUserName, string sPassword, int sUserLevel, int sUid)
        {

            UserDAO userDAO = new UserDAO();
            int iRowCount = userDAO.UpdateUser(sUserName, sPassword, sUserLevel, sUid);
            return iRowCount;
        }
    }
}
